using UnityEngine;

public class ExitGame : MonoBehaviour
{
    public void QuitGame()
    {
        Debug.Log("Quit button pressed!");

#if UNITY_EDITOR
        // Stop Play Mode when testing in the Editor
        UnityEditor.EditorApplication.isPlaying = false;
#else
        // Quit the built game
        Application.Quit();
#endif
    }
}
