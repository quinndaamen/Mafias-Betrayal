using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneSwitcher : MonoBehaviour
{
    [Header("Dialogue Reference")]
    public NPCDialogue npcDialogue; // Drag the boss/guard dialogue here in Inspector

    [Header("Scene Names")]
    public string sceneIfFalse;  // Scene to load if dialogueFinished == false
    public string sceneIfTrue;   // Scene to load if dialogueFinished == true

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            if (npcDialogue != null)
            {
                if (npcDialogue.dialogueFinished)
                {
                    SceneManager.LoadScene(sceneIfTrue);
                }
                else
                {
                    SceneManager.LoadScene(sceneIfFalse);
                }
            }
        }
    }
}
