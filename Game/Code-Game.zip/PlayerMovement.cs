using UnityEngine;

public class PlayerMovement2D : MonoBehaviour
{
    [Header("Movement")]
    public float moveSpeed = 8f;              // Ren snelijd Max
    public float acceleration = 20f;          // Accel Grond
    public float deceleration = 30f;          // DeAccel Grond
    public float airAcceleration = 10f;       // Accel in lucht
    public float airDeceleration = 15f;       // DeAccel in lucht
    [Range(0f, 1f)]
    public float airMoveSpeedMultiplier = 0.90f; // Snelheid in lucht 90% van gornd

    [Header("Jump")]
    public float jumpForce = 12f;             // Spring kracht
    public float jumpCutMultiplier = 0.5f;    // Als je eerde loslaat spring je minder hoog
    public float coyoteTime = 0.1f;           // Je hebt een groter window om te springen als je van een blok afgaat
    public float jumpBufferTime = 0.1f;       // Als je in de lucht springt en bijna op de gront land springt hij toch nog
    public Transform groundCheck;             // Checken of de speler op de grond staat(ivm Springen)
    public float groundCheckRadius = 0.2f;    // grootte cirkel die checkt
    public LayerMask groundLayer;             // welke Layer de grond is

    [Header("Components")]
    [SerializeField] private Animator animator; // Animatie controller moet hierheen wrden gesleept

    private Rigidbody2D rb;                     // Afkorting voor Rigidbody2D, kan als rb worden genoemt
    private SpriteRenderer spriteRenderer;      // geen idee

    private float moveInput;                    // krijg input van speler: -1 Links(Linker pijl, A), 0 niks, 1 Rechts(Rechter pijl, D)
    private float currentSpeed;                 // krijg snelheid van de rigidbody vn de speler
    private bool isGrounded;                    // checkt of de speler op de grond staat

    private float coyoteTimer;                  // Timer voor coyote time
    private float jumpBufferTimer;              // Timer voor jump buffer

    void Start()                                // Het eerste wat er gebeurt als de speler spawnt: gebeurt maar 1x
    {
        rb = GetComponent<Rigidbody2D>();       // krijgt de info van de Rigidbody2D component van de speler
        spriteRenderer = GetComponent<SpriteRenderer>();        // krijgt de info van de SpriteRenderer component van de speler
    }

    [System.Obsolete]
    void Update()                               // gebeurt telkes: elke frame
    {
        // --- Input ---
        moveInput = Input.GetAxisRaw("Horizontal"); // -1, 0 of 1

        if (Input.GetButtonDown("Jump"))            // als je op enter drukt
            jumpBufferTimer = jumpBufferTime;
        else                                        // check of je enter loslaat
            jumpBufferTimer -= Time.deltaTime;

        // --- Ground Check ---
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, groundLayer);         // checkt of de cirkel die gemaakt is de Laag Grond raakt

        if (isGrounded)                            // als de speler op de grond staat zet de coyote timer op de max
            coyoteTimer = coyoteTime;
        else
            coyoteTimer -= Time.deltaTime;

        // --- Jump ---
        if (jumpBufferTimer > 0f && coyoteTimer > 0f)       
        {
            rb.velocity = new Vector2(rb.velocity.x, jumpForce); // spring: zet de y snelheid op de JumpForce
            animator.SetBool("isJumping", true);
            jumpBufferTimer = 0f;
            coyoteTimer = 0f;
        }

        // Cut jump short if button released early
        if (Input.GetButtonUp("Jump") && rb.velocity.y > 0)         // als je enter loslaat en je oomhoog gaat zet de snelheid omlaag zodat hij omlaag komt en neit verder omhoog gaat 
            rb.velocity = new Vector2(rb.velocity.x, rb.velocity.y * jumpCutMultiplier);

        // --- Sprite Flip ---
        if (moveInput > 0) spriteRenderer.flipX = false;           // als de speler naar 1 rechts gaat laat sprite staan als speler -1 naar links gaat Flip de sprite
        else if (moveInput < 0) spriteRenderer.flipX = true;

        // --- Animations ---
        animator.SetBool("isJumping", !isGrounded);                // zodat je in unity de anitmaties kan veranderen

        if (Mathf.Abs(rb.velocity.x) > 0.1f && Mathf.Abs(rb.velocity.x) < 4f)
            animator.SetBool("isWalking", true);
        else
            animator.SetBool("isWalking", false);

        if (Mathf.Abs(rb.velocity.x) >= 4f)
            animator.SetBool("isRunning", true);
        else
            animator.SetBool("isRunning", false);
    }

    [System.Obsolete]
    void FixedUpdate()                            // gebeurt elke physics stap (standaard 50x per sec)
    {
        // Determine max speed depending on air or ground
        float maxSpeed = isGrounded ? moveSpeed : moveSpeed * airMoveSpeedMultiplier;       // max speed is lager in de lucht
        float targetSpeed = moveInput * maxSpeed;                                           // target speed is maxspeed x input

        // Choose acceleration/deceleration
        float accel = isGrounded ? acceleration : airAcceleration;                          // accel lucht of grond
        float decel = isGrounded ? deceleration : airDeceleration;                          // decel lucht of grond

        // Smoothly move towards target speed
        if (Mathf.Abs(moveInput) > 0.01f)                                                   // kijken of er input is
            currentSpeed = Mathf.MoveTowards(currentSpeed, targetSpeed, accel * Time.fixedDeltaTime);       // geleidelijk snelheid verhogen naar targetspeed
        else
            currentSpeed = Mathf.MoveTowards(currentSpeed, 0, decel * Time.fixedDeltaTime);                 // geleidelijk snelheid verlagen naar 0

        // Apply horizontal velocity
        rb.velocity = new Vector2(currentSpeed, rb.velocity.y);                 // zodat de y snel;heid niet veranderd 
    }

    // Optional: visualize ground check
    void OnDrawGizmosSelected()
    {
        if (groundCheck != null)
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(groundCheck.position, groundCheckRadius);
        }
    }
}
