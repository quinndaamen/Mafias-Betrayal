using UnityEngine;
using UnityEngine.SceneManagement; // nodig voor de scene reloads

public class Enemy : MonoBehaviour
{
    void Update()
    {
        
    }

    private void OnCollisionEnter2D(Collision2D other)  // checkt voor collision met object met TAG Player
    {
        if (other.gameObject.CompareTag("Player"))
        {
            Debug.Log("Player hit! Restarting level...");

            // Reload the current active scene
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);   // Reload de huidige scene als de speler de enemy raakt
        }
    }

    private void OnTriggerEnter2D(Collider2D other)     // checkt voor trigger met object met TAG Player
    {
        if (other.CompareTag("Player"))
        {
            Debug.Log("Player hit! Restarting level...");

            // Reload the current active scene
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }
}