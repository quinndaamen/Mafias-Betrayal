using UnityEngine;
using UnityEngine.SceneManagement;

public class MusicManager : MonoBehaviour
{
    private static MusicManager instance;
    private AudioSource audioSource;

    //  waar de musizke moet spelen
    private string[] menuScenes = { "Main-Menu", "Start-menu", "select-level" };

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject); // audio blijft spelen en stopt nie to door dont destroy on load
            audioSource = GetComponent<AudioSource>();
            audioSource.loop = true;

            SceneManager.sceneLoaded += OnSceneLoaded; // listen to scene changes
            HandleMusic(SceneManager.GetActiveScene().name); // check current scene
        }
        else
        {
            Destroy(gameObject); // remove duplicates
        }
    }

    void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        HandleMusic(scene.name);
    }

    void HandleMusic(string sceneName)
    {
        // Play music if in menu, stop if in gameplay
        if (System.Array.Exists(menuScenes, s => s == sceneName))
        {
            if (!audioSource.isPlaying)
                audioSource.Play();
        }
        else
        {
            if (audioSource.isPlaying)
                audioSource.Stop();
        }
    }

    void OnDestroy()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }
}
