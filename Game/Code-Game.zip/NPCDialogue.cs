using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class NPCDialogue : MonoBehaviour
{
    [Header("References")]
    public GameObject dialoguePanel;   // DialoguePanel in Canvas
    public Image portrait;             // Portrait image
    public TMP_Text nameText;          // Name text
    public TMP_Text dialogueText;      // Dialogue text

    [Header("NPC Info")]
    public Sprite npcPortrait;
    public string npcName = "NPC";
    [TextArea(3, 5)]
    public string[] dialogueLines;

    [Header("Dialogue Settings")]
    public bool setTrueOnEnd = false;   // 👈 Tick this for the dialogue you care about
    [HideInInspector] public bool dialogueFinished = false;

    private int currentLine = 0;
    private bool playerInRange = false;
    private bool isTalking = false;

    void Start()
    {
        dialoguePanel.SetActive(false);
        dialogueFinished = false;
    }

    void Update()
    {
        if (playerInRange && Input.GetKeyDown(KeyCode.E))
        {
            if (!isTalking)
            {
                StartDialogue();
            }
            else
            {
                NextLine();
            }
        }
    }

    void StartDialogue()
    {
        if (dialogueLines.Length == 0) return;

        isTalking = true;
        currentLine = 0;
        dialogueFinished = false;

        dialoguePanel.SetActive(true);
        portrait.sprite = npcPortrait;
        nameText.text = npcName;
        dialogueText.text = dialogueLines[currentLine];
    }

    void NextLine()
    {
        currentLine++;
        if (currentLine < dialogueLines.Length)
        {
            dialogueText.text = dialogueLines[currentLine];
        }
        else
        {
            EndDialogue();
        }
    }

    void EndDialogue()
    {
        isTalking = false;
        dialoguePanel.SetActive(false);

        if (setTrueOnEnd)
        {
            dialogueFinished = true; // 👈 This is your flag
            Debug.Log($"{npcName} dialogue finished → dialogueFinished set TRUE");
        }
    }

    // Trigger detection
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = true;
            Debug.Log("Player in range of NPC. Press E to interact.");
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = false;
            if (isTalking) EndDialogue();
        }
    }
}
