using UnityEngine;
using UnityEngine.SceneManagement;

public class Finish : MonoBehaviour
{
    public string leaderboardSceneName = "Leaderboard"; // naam van de leaderboard scene

    private void OnTriggerEnter2D(Collider2D other)  // checkt of de speler de finsish rakt
    {
        if (other.CompareTag("Player"))
        {
            float currentTime = Timer.instance.GetTime();       // haalt tijd van timer op moment met collision

            int levelIndex = SceneManager.GetActiveScene().buildIndex;  // haalt index van huidige scene op 
            string key = "BestTime_Level" + levelIndex;                 // maakt key voor PlayerPrefs (Beste tijd pe level)

            float bestTime = PlayerPrefs.GetFloat(key, float.MaxValue); // haalt de beste tijd op, of float.MaxValue als er nog geen tijd is

            bool improved = currentTime < bestTime;                     // checkt of de huidige tijd beter is dan de beste tijd

            if (improved)
                PlayerPrefs.SetFloat(key, currentTime);                 // slaat de nieuwe beste tijd op als die beter is

            // sla de laatste level, tijd en of de speler zijn beste tijd heeft verbeterd op
            PlayerPrefs.SetInt("LastLevel", levelIndex);        
            PlayerPrefs.SetFloat("LastRunTime", currentTime);
            PlayerPrefs.SetInt("Improved", improved ? 1 : 0);

            PlayerPrefs.Save();

            SceneManager.LoadScene(leaderboardSceneName);
        }
    }
}
