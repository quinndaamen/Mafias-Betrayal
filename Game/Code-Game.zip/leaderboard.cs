using UnityEngine;
using TMPro;

public class Leaderboard : MonoBehaviour
{
    public TextMeshProUGUI leaderboardText;

    [Header("Author Info")]
    public string authorName = "Quinn";

    [Header("Medal Thresholds per Level")]
    public float[] goldTimes;    // per level
    public float[] silverTimes;
    public float[] bronzeTimes;

    [Header("Author Record")] 
    public float[] authorTimes; // mijn records per level

    void Start()
    {
        int lastLevel = PlayerPrefs.GetInt("LastLevel", -1);    // haalt de laatste level op die gespeeld is
        float lastRun = PlayerPrefs.GetFloat("LastRunTime", -1f);       // haalt de tijd van de laatste run op
        bool improved = PlayerPrefs.GetInt("Improved", 0) == 1;         // haalt op of de speler zijn beste tijd heeft verbeterd

        string text = $"<b>🏁 Leaderboard</b>\n<b>Author: {authorName}</b>\n\n";

        for (int i = 1; i <= 4; i++)
        {
            string key = "BestTime_Level" + i;
            float bestTime = PlayerPrefs.GetFloat(key, -1f);

            string medalText = GetMedal(i, bestTime);
            string authorMedal = GetAuthorMedal(i, bestTime);

            if (bestTime >= 0)
            {
                if (i == lastLevel)
                {
                    if (improved)
                        text += $"<color=green>Level {i}: {bestTime:F3}s {medalText} {authorMedal} (New Record!)</color>\n";
                    else
                        text += $"<color=yellow>Level {i}: {bestTime:F3}s {medalText} {authorMedal} (Your run: {lastRun:F3}s)</color>\n";
                }
                else
                {
                    text += $"Level {i}: {bestTime:F3}s {medalText} {authorMedal}\n";
                }
            }
            else
            {
                text += $"Level {i}: ---\n";
            }
        }

        leaderboardText.text = text;
    }

    string GetMedal(int level, float time)          // kijkt welke medal de speler heeft gehaald
    {
        if (level - 1 >= goldTimes.Length || time < 0) return "";
        if (time <= authorTimes[level - 1])
            return "A"; // Author medal
        if (time <= goldTimes[level - 1])
            return "G"; // Gold
        else if (time <= silverTimes[level - 1])
            return "S"; // Silver
        else if (time <= bronzeTimes[level - 1])
            return "B"; // Bronze
        else
            return "";
    }

    string GetAuthorMedal(int level, float time) // niet nodig werkt in code hierboven
    {
        if (level - 1 >= authorTimes.Length || time < 0) return "";

        if (Mathf.Approximately(time, authorTimes[level - 1]))
            return "A"; // Author medal
        return "";
    }
}
