using UnityEngine;

public class EnemyFollowOnDialogue : MonoBehaviour
{
    [Header("Relative Moves")]
    public Vector2[] moves;       // Example: (-10,0), (0,-10), (5,0)
    public float speed = 5f;

    [Header("Dialogue Reference")]
    public NPCDialogue bossDialogue;  // Drag your NPCDialogue here

    private int currentMove = 0;
    private Vector2 targetPos;
    private bool startMoving = false;

    void Start()
    {
        if (moves.Length > 0)
            targetPos = (Vector2)transform.position + moves[0];
    }

    void Update()
    {
        // Automatically start when dialogue finishes
        if (!startMoving && bossDialogue != null && bossDialogue.dialogueFinished)
        {
            startMoving = true;
        }

        if (!startMoving || moves.Length == 0) return;

        // Move towards target
        transform.position = Vector2.MoveTowards(transform.position, targetPos, speed * Time.deltaTime);

        // Check if reached target
        if (Vector2.Distance(transform.position, targetPos) < 0.05f)
        {
            currentMove++;
            if (currentMove >= moves.Length)
            {
                startMoving = false; // stop after last move
                return;
            }

            // Next target relative to current position
            targetPos = (Vector2)transform.position + moves[currentMove];
        }
    }
}
