using UnityEngine;
using UnityEngine.SceneManagement; // nodig voor de scene reloads

public class EnemyRunner : MonoBehaviour
{
    public float speed = 3f;             // snelheid van enemy
    public float leftBound = -10f;       // positie linkerkant
    public float rightBound = 10f;       // positie rechterkant
    public bool startLeft = true;        // kijkt of de enemy links of rechts start

    private bool movingRight;

    void Start()
    {
        // zet begin richting
        movingRight = !startLeft;
    }

    void Update()
    {
        // maakt dat de enemy beweegt richting de grensen en dan terug
        if (movingRight)
        {
            transform.Translate(Vector2.right * speed * Time.deltaTime);
            if (transform.position.x >= rightBound)
                movingRight = false; // turn left
        }
        else
        {
            transform.Translate(Vector2.left * speed * Time.deltaTime);
            if (transform.position.x <= leftBound)
                movingRight = true; // turn right
        }
    }

    private void OnCollisionEnter2D(Collision2D other)      // als collision met object met TAG Player restart de level
    {
        if (other.gameObject.CompareTag("Player"))
        {
            Debug.Log("Player hit! Restarting level...");

            // Reload the current active scene
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)         // als trigger met object met TAG Player restart de level 
    {
        if (other.CompareTag("Player"))
        {
            Debug.Log("Player hit! Restarting level...");

            // Reload the current active scene
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }
}
