using UnityEngine;
using UnityEngine.SceneManagement;

public class LeaderboardReset : MonoBehaviour
{
    [ContextMenu("Reset Leaderboard")]
    void ResetLeaderboard()
    {
        for (int i = 1; i <= 4; i++)
            PlayerPrefs.DeleteKey("BestTime_Level" + i);

        PlayerPrefs.DeleteKey("LastRunTime");
        PlayerPrefs.DeleteKey("LastLevel");
        PlayerPrefs.DeleteKey("Improved");

        PlayerPrefs.Save();

        Debug.Log("Leaderboard reset!");
    }
}
