using UnityEngine;

public class PlayerLandingSound : MonoBehaviour
{
    public AudioSource audioSource;
    public AudioClip landingClip;

    private bool isGrounded = true; 
    private int groundLayer;

    void Start()
    {
        // get layer index of "Ground" layer
        groundLayer = LayerMask.NameToLayer("Ground");
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.layer == groundLayer)
        {
            if (!isGrounded) // only play if coming from air
            {
                audioSource.PlayOneShot(landingClip);
            }
            isGrounded = true;
        }
    }

    void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.layer == groundLayer)
        {
            isGrounded = false;
        }
    }
}
