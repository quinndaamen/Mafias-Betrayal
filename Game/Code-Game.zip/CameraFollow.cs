using UnityEngine;

public class CameraFollow2D : MonoBehaviour
{
    public Transform target;             // Speler transform
    public Vector3 offset = new Vector3(4f, 2.8f, -20f);
    public float smoothTime = 0.3f;
    public float verticalDeadZone = 2f;  // Op welke hoogte de camera mee gaat met de speler

    private Vector3 velocity = Vector3.zero;
    private float baseY;  // welke y de camera moet blijven tot dat de speler hoger springt

    void Start()
    {
        baseY = target.position.y; // beginnen op de start positie van de speler
    }

    void LateUpdate()
    {
        if (target == null) return;

        float targetY = baseY;

        // If player jumps above dead zone -> raise camera baseline
        if (target.position.y > baseY + verticalDeadZone)
        {
            targetY = target.position.y - verticalDeadZone;
        }
        // If player goes below baseline -> reset baseline down
        else if (target.position.y < baseY)
        {
            targetY = target.position.y;
        }

        // Update baseline gradually
        baseY = Mathf.Lerp(baseY, targetY, Time.deltaTime * 5f);

        // Apply offset
        Vector3 targetPos = new Vector3(
            target.position.x + offset.x,
            baseY + offset.y,
            offset.z
        );

        // Smooth movement
        transform.position = Vector3.SmoothDamp(transform.position, targetPos, ref velocity, smoothTime);
    }
}
