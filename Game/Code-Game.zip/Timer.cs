using UnityEngine;
using TMPro; // Only if you want UI text, otherwise remove

public class Timer : MonoBehaviour
{
    public static Timer instance;

    public TextMeshProUGUI timerText; // drag your UI text here (optional)
    
    private float timeElapsed;
    private bool isRunning;

    private void Awake()
    {
        // Make it a singleton so Finish can access it
        if (instance == null) instance = this;
        else Destroy(gameObject);
    }

    private void Start()
    {
        StartTimer(); // Start automatically (remove if you want manual control)
    }

    private void Update()
    {
        if (isRunning)
        {
            timeElapsed += Time.deltaTime;

            if (timerText != null)
            {
                timerText.text = timeElapsed.ToString("F3"); // format 0.00
            }
        }
    }

    public void StartTimer()
    {
        timeElapsed = 0f;
        isRunning = true;
    }

    public void StopTimer()
    {
        isRunning = false;
    }

    public float GetTime()
    {
        return timeElapsed;
    }
}
