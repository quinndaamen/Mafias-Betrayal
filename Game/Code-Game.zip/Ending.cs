using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
using System.Collections;

public class EndSceneManager : MonoBehaviour
{
    [Header("UI References")]
    public TextMeshProUGUI revealText; // Drag your TMP text here in Inspector

    [Header("Settings")]
    public float typingSpeed = 0.05f; // Delay between characters

    private string[] dialogueLines =
    {
        "Bonjourno... this is Boss speaking.",
        "You’re lucky you made it out of there alive.",
        "The Boss don’t forgive rats. And right now, everyone thinks you’re the one.",
        "But turns out... you were never the rat.",
        "The real traitor’s already been dealt with.",
        "But remember... once trust is broken, it can never be fixed."
    };

    private int index = 0;
    private bool isTyping = false;

    void Start()
    {
        if (dialogueLines.Length > 0)
        {
            StartCoroutine(TypeLine());
        }
        else
        {
            Debug.LogWarning("No dialogue lines set in EndSceneManager!");
        }
    }

    IEnumerator TypeLine()
    {
        isTyping = true;
        revealText.text = "";

        foreach (char c in dialogueLines[index].ToCharArray())
        {
            revealText.text += c;
            yield return new WaitForSeconds(typingSpeed);
        }

        isTyping = false;
    }

    void Update()
    {
        // Press E to continue to next line
        if (Input.GetKeyDown(KeyCode.E))
        {
            NextLine();
        }
    }

    public void NextLine()
    {
        if (isTyping) return; // Prevent skipping while typing

        if (index < dialogueLines.Length - 1)
        {
            index++;
            StopAllCoroutines();
            StartCoroutine(TypeLine());
        }
        else
        {
            // When dialogue ends, return to main menu
            SceneManager.LoadScene("Main-Menu");
        }
    }
}
