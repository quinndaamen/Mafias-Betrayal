using UnityEngine;
using TMPro;

public class PlayerSpeedMeterTMP : MonoBehaviour
{
    public Rigidbody2D rb;
    public TMP_Text speedText;

    [System.Obsolete]
    void Update()
    {
        float speed = rb.velocity.x;
        speedText.text = $"Speed: {speed:F2}";
    }
}
