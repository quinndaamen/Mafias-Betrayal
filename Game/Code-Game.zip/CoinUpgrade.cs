using UnityEngine;
using System.Collections;

public class SpeedCoin : MonoBehaviour
{
    public float speedBoost = 1f;        // Hoeveel speedboost de speler krijgt
    public float boostDuration = 5f;     // Hoe lang de boost duurt(werkt niet)

    private void OnTriggerEnter2D(Collider2D other)     // checkt voor trigger met object met TAG Player
    {
        if (other.CompareTag("Player"))
        {
            PlayerMovement2D player = other.GetComponent<PlayerMovement2D>();
            if (player != null)
            {
                StartCoroutine(ApplySpeedBoost(player));
            }

            Destroy(gameObject); // als speler de coin raakt, verdwijnt die
        }
    }

    private IEnumerator ApplySpeedBoost(PlayerMovement2D player) // Geeft de speler via coroutine een speed boost
    {
        player.moveSpeed += speedBoost;       // geeft speed boost
        yield return new WaitForSeconds(boostDuration);
        player.moveSpeed -= speedBoost;       // als tijd over is trekt de snelheid er weer vanaf
    }
}
