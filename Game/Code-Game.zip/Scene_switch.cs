using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneTransition : MonoBehaviour
{
    [Header("Scene Settings")]
    public string nextSceneName = "Scene-2"; // Set the scene you want to load in the Inspector

    private void OnTriggerEnter2D(Collider2D other)
    {
        // Check if the player entered the trigger
        if (other.CompareTag("Player"))
        {
            // Optional: check if this object should trigger the scene change
            // if (gameObject.name == "trigger-warehouse01" || gameObject.CompareTag("Interactions"))
            {
                // Load the next scene
                SceneManager.LoadScene(nextSceneName);
                Debug.Log("Loading scene: " + nextSceneName);
            }
        }
    }
}
