using UnityEngine;
using TMPro;

public class ShowText : MonoBehaviour
{
    public TextMeshProUGUI myText; // drag UI text here

    void Start()
    {
        if (myText != null)
            myText.gameObject.SetActive(false);
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            if (myText != null)
                myText.gameObject.SetActive(true);
        }
    }
}
